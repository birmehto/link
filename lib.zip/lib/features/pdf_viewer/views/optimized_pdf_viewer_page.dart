import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:get/get.dart';
import 'package:pdfx/pdfx.dart';
import 'package:visibility_detector/visibility_detector.dart';

import '../controllers/pdf_viewer_controller.dart';

/// Optimized stateless PDF viewer page with performance enhancements
class OptimizedPdfViewerPage extends StatelessWidget {
  final String pdfUrl;
  final String? title;

  const OptimizedPdfViewerPage({super.key, required this.pdfUrl, this.title});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(
      PdfViewerPageController(),
      tag: pdfUrl, // Use URL as tag for unique instances
    );

    // Initialize the controller with PDF URL and title
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.initialize(pdfUrl, title);
    });

    return VisibilityDetector(
      key: Key('pdf-viewer-$pdfUrl'),
      onVisibilityChanged: (info) {
        controller.onVisibilityChanged(info.visibleFraction > 0.1);
      },
      child: Scaffold(
        body: Column(
          children: [
            _buildAppBar(context, controller),
            Expanded(child: _buildBody(context, controller)),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar(
    BuildContext context,
    PdfViewerPageController controller,
  ) {
    return Obx(
      () => AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title ?? 'PDF Viewer',
              style: const TextStyle(fontSize: 16),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            if (controller.totalPages.value > 0)
              Text(
                'Page ${controller.currentPageNumber.value} of ${controller.totalPages.value}',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(
                    context,
                  ).colorScheme.onSurface.withValues(alpha: 0.7),
                ),
              ),
          ],
        ),
        actions: [
          if (controller.isLoading.value)
            Container(
              margin: const EdgeInsets.all(8),
              width: 24,
              height: 24,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                value: controller.downloadProgress.value > 0
                    ? controller.downloadProgress.value
                    : null,
              ),
            ),
          IconButton(
            onPressed: controller.sharePdf,
            icon: const Icon(Icons.share),
            tooltip: 'Share PDF',
          ),
          IconButton(
            onPressed: controller.isDownloading.value
                ? null
                : controller.downloadPdf,
            icon: controller.isDownloading.value
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.download),
            tooltip: 'Download PDF',
          ),
          PopupMenuButton<String>(
            onSelected: (value) => _handleMenuAction(value, controller),
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'fullscreen',
                child: ListTile(
                  leading: const Icon(Icons.fullscreen),
                  title: const Text('Toggle Fullscreen'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: 'browser',
                child: ListTile(
                  leading: const Icon(Icons.open_in_browser),
                  title: const Text('Open in Browser'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: 'cache_clear',
                child: ListTile(
                  leading: const Icon(Icons.clear_all),
                  title: const Text('Clear Cache'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: 'zoom_reset',
                child: ListTile(
                  leading: const Icon(Icons.zoom_out_map),
                  title: const Text('Reset Zoom'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBody(BuildContext context, PdfViewerPageController controller) {
    return Obx(() {
      if (controller.isLoading.value) {
        return _buildLoadingState(controller);
      }

      if (controller.hasError.value) {
        return _buildErrorState(controller);
      }

      if (!controller.hasDocument || controller.pdfController == null) {
        return _buildEmptyState();
      }

      return _buildPdfViewer(context, controller);
    });
  }

  Widget _buildLoadingState(PdfViewerPageController controller) {
    return Container(
      color: Colors.black.withValues(alpha: 0.05),
      child: Center(
        child:
            Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 80,
                      height: 80,
                      child: CircularProgressIndicator(
                        strokeWidth: 3,
                        value: controller.downloadProgress.value > 0
                            ? controller.downloadProgress.value
                            : null,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Text(
                      'Loading PDF...',
                      style: Get.textTheme.titleMedium?.copyWith(
                        color: Get.theme.colorScheme.onSurface,
                      ),
                    ),
                    if (controller.downloadProgress.value > 0) ...[
                      const SizedBox(height: 12),
                      Text(
                        '${(controller.downloadProgress.value * 100).toInt()}%',
                        style: Get.textTheme.bodyMedium?.copyWith(
                          color: Get.theme.colorScheme.onSurface.withValues(
                            alpha: 0.7,
                          ),
                        ),
                      ),
                    ],
                  ],
                )
                .animate()
                .fadeIn(duration: 300.ms)
                .scale(begin: const Offset(0.8, 0.8)),
      ),
    );
  }

  Widget _buildErrorState(PdfViewerPageController controller) {
    return Container(
      padding: const EdgeInsets.all(32),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 64,
              color: Get.theme.colorScheme.error,
            ).animate().fadeIn(duration: 300.ms).shake(duration: 500.ms, hz: 2),
            const SizedBox(height: 24),
            Text(
              'Failed to Load PDF',
              style: Get.textTheme.headlineSmall?.copyWith(
                color: Get.theme.colorScheme.error,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Text(
              controller.errorMessage.value,
              style: Get.textTheme.bodyMedium?.copyWith(
                color: Get.theme.colorScheme.onSurface.withValues(alpha: 0.8),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton.icon(
                  onPressed: controller.retry,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Retry'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 12,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                OutlinedButton.icon(
                  onPressed: controller.openInBrowser,
                  icon: const Icon(Icons.open_in_browser),
                  label: const Text('Open in Browser'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 12,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ).animate().fadeIn(duration: 500.ms, delay: 200.ms),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.picture_as_pdf,
            size: 64,
            color: Get.theme.colorScheme.onSurface.withValues(alpha: 0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'No PDF Available',
            style: Get.textTheme.titleMedium?.copyWith(
              color: Get.theme.colorScheme.onSurface.withValues(alpha: 0.8),
            ),
          ),
        ],
      ).animate().fadeIn(duration: 300.ms),
    );
  }

  Widget _buildPdfViewer(
    BuildContext context,
    PdfViewerPageController controller,
  ) {
    return GestureDetector(
      onTap: controller.toggleControls,
      child: Stack(
        children: [
          // PDF Viewer
          PdfView(
            controller: controller.pdfController!,
            scrollDirection: Axis.vertical,
            pageSnapping: true,
            physics: const BouncingScrollPhysics(),
            onPageChanged: (pageNumber) {
              controller.onPageChanged(pageNumber);
            },
            onDocumentLoaded: (document) {
              // Document loaded callback handled in controller
            },
            onDocumentError: (error) {
              // Error handling done in controller
            },
            renderer: (PdfPage page) => page.render(
              width: page.width * 2, // Higher resolution for crisp text
              height: page.height * 2,
              format: PdfPageImageFormat.jpeg,
              backgroundColor: '#FFFFFF',
            ),
          ),

          // Control overlay
          Obx(
            () => AnimatedOpacity(
              opacity: controller.showControls.value ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 300),
              child: controller.showControls.value
                  ? _buildControlsOverlay(context, controller)
                  : const SizedBox.shrink(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildControlsOverlay(
    BuildContext context,
    PdfViewerPageController controller,
  ) {
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: Get.theme.colorScheme.surface.withValues(alpha: 0.95),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 20,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Page navigation
            Row(
              children: [
                IconButton(
                  onPressed: controller.currentPageNumber.value > 1
                      ? () {
                          HapticFeedback.selectionClick();
                          controller.previousPage();
                        }
                      : null,
                  icon: const Icon(Icons.navigate_before),
                  tooltip: 'Previous Page',
                ),
                Expanded(
                  child: GestureDetector(
                    onTap: () => _showPageJumpDialog(context, controller),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Text(
                        'Page ${controller.currentPageNumber.value} of ${controller.totalPages.value}',
                        style: Get.textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w500,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ),
                IconButton(
                  onPressed:
                      controller.currentPageNumber.value <
                          controller.totalPages.value
                      ? () {
                          HapticFeedback.selectionClick();
                          controller.nextPage();
                        }
                      : null,
                  icon: const Icon(Icons.navigate_next),
                  tooltip: 'Next Page',
                ),
              ],
            ),

            // Zoom controls
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  onPressed: () {
                    HapticFeedback.selectionClick();
                    controller.zoomOut();
                  },
                  icon: const Icon(Icons.zoom_out),
                  tooltip: 'Zoom Out',
                ),
                Obx(
                  () => Text(
                    '${(controller.zoomLevel.value * 100).toInt()}%',
                    style: Get.textTheme.bodySmall?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () {
                    HapticFeedback.selectionClick();
                    controller.zoomIn();
                  },
                  icon: const Icon(Icons.zoom_in),
                  tooltip: 'Zoom In',
                ),
              ],
            ),
          ],
        ),
      ).animate().slideY(begin: 1.0, duration: 300.ms, curve: Curves.easeOut),
    );
  }

  void _handleMenuAction(String action, PdfViewerPageController controller) {
    switch (action) {
      case 'fullscreen':
        controller.toggleFullscreen();
        break;
      case 'browser':
        controller.openInBrowser();
        break;
      case 'cache_clear':
        controller.clearCache();
        Get.snackbar(
          'Cache Cleared',
          'PDF cache has been cleared successfully',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Get.theme.colorScheme.primaryContainer,
          colorText: Get.theme.colorScheme.onPrimaryContainer,
        );
        break;
      case 'zoom_reset':
        controller.resetZoom();
        break;
    }
  }

  void _showPageJumpDialog(
    BuildContext context,
    PdfViewerPageController controller,
  ) {
    final textController = TextEditingController(
      text: controller.currentPageNumber.value.toString(),
    );

    Get.dialog(
      AlertDialog(
        title: const Text('Go to Page'),
        content: TextField(
          controller: textController,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
            labelText: 'Page number (1-${controller.totalPages.value})',
            border: const OutlineInputBorder(),
          ),
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Get.back(), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final pageNumber = int.tryParse(textController.text);
              if (pageNumber != null &&
                  pageNumber >= 1 &&
                  pageNumber <= controller.totalPages.value) {
                HapticFeedback.selectionClick();
                controller.jumpToPage(pageNumber);
                Get.back();
              } else {
                Get.snackbar(
                  'Invalid Page',
                  'Please enter a valid page number between 1 and ${controller.totalPages.value}',
                  snackPosition: SnackPosition.BOTTOM,
                  backgroundColor: Get.theme.colorScheme.errorContainer,
                  colorText: Get.theme.colorScheme.onErrorContainer,
                );
              }
            },
            child: const Text('Go'),
          ),
        ],
      ),
    );
  }
}
