import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:visibility_detector/visibility_detector.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../models/book.dart';

/// Optimized book card widget with lazy loading and performance enhancements
class OptimizedBookCard extends StatelessWidget {
  final Book book;
  final VoidCallback onTap;
  final int index;

  const OptimizedBookCard({
    super.key,
    required this.book,
    required this.onTap,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    return VisibilityDetector(
      key: Key('book-card-${book.workId}'),
      onVisibilityChanged: (info) {
        // Preload images when card becomes visible
        if (info.visibleFraction > 0.1 && book.hasCover) {
          precacheImage(
            CachedNetworkImageProvider(book.coverUrl!),
            context,
          );
        }
      },
      child: Card(
        elevation: 1,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
          color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.2),
          ),
        ),
        color: Theme.of(context).colorScheme.surfaceContainerLowest,
        child: InkWell(
          onTap: () {
            HapticFeedback.selectionClick();
            onTap();
          },
          borderRadius: BorderRadius.circular(16),
          child: _buildCardContent(context),
        ),
      ).animate(delay: Duration(milliseconds: index * 50))
        .fadeIn(duration: 400.ms, curve: Curves.easeOut)
        .slideY(begin: 0.1, duration: 400.ms, curve: Curves.easeOut),
    );
  }

  Widget _buildCardContent(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildBookCover(context),
          const SizedBox(width: 16),
          Expanded(child: _buildBookInfo(context)),
        ],
      ),
    );
  }

  Widget _buildBookCover(BuildContext context) {
    return Hero(
      tag: 'book-cover-${book.workId}',
      child: Container(
        width: 80,
        height: 120,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: book.hasCover
              ? CachedNetworkImage(
                  imageUrl: book.coverUrl!,
                  fit: BoxFit.cover,
                  fadeInDuration: const Duration(milliseconds: 300),
                  fadeOutDuration: const Duration(milliseconds: 100),
                  placeholder: (context, url) => _buildCoverPlaceholder(),
                  errorWidget: (context, url, error) => _buildCoverPlaceholder(),
                  memCacheWidth: 160, // Optimize memory usage
                  memCacheHeight: 240,
                )
              : _buildCoverPlaceholder(),
        ),
      ),
    );
  }

  Widget _buildCoverPlaceholder() {
    return Container(
      color: Get.theme.colorScheme.surfaceContainer,
      child: Center(
        child: Icon(
          Icons.book,
          size: 40,
          color: Get.theme.colorScheme.onSurface.withValues(alpha: 0.3),
        ),
      ),
    );
  }

  Widget _buildBookInfo(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildTitle(context),
        const SizedBox(height: 8),
        if (book.authorName != null) ...[
          _buildAuthor(context),
          const SizedBox(height: 4),
        ],
        _buildMetaBadges(context),
        if (_shouldShowDescription()) ...[
          const SizedBox(height: 8),
          _buildDescription(context),
        ],
        const SizedBox(height: 8),
        _buildBottomRow(context),
      ],
    );
  }

  Widget _buildTitle(BuildContext context) {
    return Text(
      book.title,
      style: Theme.of(context).textTheme.titleMedium?.copyWith(
        fontWeight: FontWeight.bold,
        height: 1.2,
      ),
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildAuthor(BuildContext context) {
    return Row(
      children: [
        Icon(
          Icons.person_outline,
          size: 16,
          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
        ),
        const SizedBox(width: 4),
        Expanded(
          child: Text(
            book.displayAuthor,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.8),
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Widget _buildMetaBadges(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        if (book.hasRating) _buildRatingBadge(context),
        if (book.firstPublishYear != null) _buildYearBadge(context),
      ],
    );
  }

  Widget _buildRatingBadge(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.amber.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.amber.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.star, size: 12, color: Colors.amber),
          const SizedBox(width: 4),
          Text(
            book.formattedRating,
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurface,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildYearBadge(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.2),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.calendar_today_outlined,
            size: 12,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(width: 4),
          Text(
            book.publishYear,
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: Theme.of(context).colorScheme.primary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDescription(BuildContext context) {
    return Text(
      book.shortDescription,
      style: Theme.of(context).textTheme.bodySmall?.copyWith(
        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
        height: 1.3,
      ),
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildBottomRow(BuildContext context) {
    return Row(
      children: [
        if (book.subjects.isNotEmpty) _buildSubjectChip(context),
        const Spacer(),
        if (book.hasPdf) _buildPdfBadge(context),
      ],
    );
  }

  Widget _buildSubjectChip(BuildContext context) {
    return Chip(
      label: Text(
        book.subjects.first,
        style: Theme.of(context).textTheme.labelSmall,
      ),
      backgroundColor: Theme.of(context).primaryColor.withValues(alpha: 0.1),
      side: BorderSide.none,
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      visualDensity: VisualDensity.compact,
    );
  }

  Widget _buildPdfBadge(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.green.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.picture_as_pdf,
            size: 12,
            color: Colors.green.shade700,
          ),
          const SizedBox(width: 4),
          Text(
            'PDF',
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: Colors.green.shade700,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  bool _shouldShowDescription() {
    return book.shortDescription.isNotEmpty && 
           book.shortDescription != 'No description available.';
  }
}
