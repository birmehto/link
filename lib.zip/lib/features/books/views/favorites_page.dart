import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:link/shared/widgets/app_state_message.dart';

import '../../home/controllers/home_controller.dart';

/// Page for viewing favorite/saved books
class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
          SliverAppBar(
            expandedHeight: 120,
            floating: false,
            pinned: true,
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                'Favorites',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
              centerTitle: false,
              titlePadding: const EdgeInsets.only(left: 20, bottom: 16),
            ),
            actions: [
              IconButton(
                onPressed: () {
                  // TODO: Clear all favorites with confirmation
                },
                icon: const Icon(Icons.clear_all),
                tooltip: 'Clear All',
              ),
            ],
          ),
          SliverFillRemaining(
            hasScrollBody: false,
            child: _buildEmptyState(context),
          ),
        ],
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return SafeArea(
      top: false,
      child: AppStateMessage(
        icon: Icons.favorite_outline,
        iconColor: Theme.of(context).primaryColor,
        title: 'No Favorites Yet',
        message:
            'Books you favorite will appear here. Start exploring and save your favorite books!',
        primaryLabel: 'Explore Books',
        onPrimary: () {
          final homeController = Get.find<HomeController>();
          homeController.goToHome();
        },
      ),
    );
  }
}