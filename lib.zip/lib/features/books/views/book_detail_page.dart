import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:link/shared/widgets/app_state_message.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../shared/widgets/skeleton_loader.dart';

import '../../../core/routes/app_routes.dart';
import '../../../core/services/deep_link_service.dart';
import '../controllers/book_detail_controller.dart';

/// Book detail page showing detailed information about a specific book
class BookDetailPage extends StatelessWidget {
  final String bookId;

  const BookDetailPage({super.key, required this.bookId});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(
      BookDetailController(),
      tag: bookId, // Use bookId as tag to allow multiple instances
    );

    // Initialize the controller with the bookId
    controller.initialize(bookId);

    return Scaffold(body: Obx(() => _buildBody(context, controller)));
  }

  Widget _buildBody(BuildContext context, BookDetailController controller) {
    if (controller.isLoading.value) {
      return _buildLoadingState();
    }

    if (controller.error.value.isNotEmpty) {
      return _buildErrorState(controller);
    }

    final book = controller.book.value;
    if (book == null) {
      return _buildNotFoundState();
    }

    return CustomScrollView(
      slivers: [
        _buildAppBar(context, book, controller),
        SliverToBoxAdapter(child: _buildBookContent(context, book)),
      ],
    );
  }

  Widget _buildAppBar(
    BuildContext context,
    book,
    BookDetailController controller,
  ) {
    return SliverAppBar(
      expandedHeight: 300,
      collapsedHeight: 64,
      floating: false,
      pinned: true,
      flexibleSpace: FlexibleSpaceBar(
        title: Text(
          book.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
            color: Colors.white,
            shadows: const [
              Shadow(
                offset: Offset(0, 1),
                blurRadius: 3,
                color: Colors.black54,
              ),
            ],
          ),
        ),
        titlePadding: const EdgeInsets.only(left: 16, bottom: 8),
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Theme.of(context).primaryColor.withValues(alpha: 0.8),
                Theme.of(context).primaryColor.withValues(alpha: 0.4),
              ],
            ),
          ),
          child: book.hasCover
              ? Stack(
                  children: [
                    Positioned.fill(
                      child: Image.network(
                        book.coverUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) =>
                            _buildCoverPlaceholder(),
                      ),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            Colors.black.withValues(alpha: 0.7),
                          ],
                        ),
                      ),
                    ),
                  ],
                )
              : _buildCoverPlaceholder(),
        ),
      ),
      actions: [
        IconButton(
          onPressed: () => _shareBook(book),
          icon: const Icon(Icons.share),
          tooltip: 'Share Book',
        ),
      ],
    );
  }

  Widget _buildCoverPlaceholder() {
    return Container(
      color: Colors.grey.shade300,
      child: const Center(
        child: Icon(Icons.book, size: 80, color: Colors.grey),
      ),
    );
  }

  Widget _buildBookContent(BuildContext context, book) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Book info section
            _buildBookInfo(context, book)
                .animate()
                .fadeIn(duration: 400.ms, delay: 100.ms)
                .slideY(begin: 0.2, duration: 400.ms),
            const SizedBox(height: 24),

            // Action buttons
            _buildActionButtons(context, book)
                .animate()
                .fadeIn(duration: 400.ms, delay: 200.ms)
                .slideY(begin: 0.2, duration: 400.ms),
            const SizedBox(height: 24),

          // Description
          if (book.description != null && book.description!.isNotEmpty)
            _buildDescriptionSection(context, book),

          // Subjects
          if (book.subjects.isNotEmpty) _buildSubjectsSection(context, book),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildBookInfo(BuildContext context, book) {
    final theme = Theme.of(context);
    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: theme.colorScheme.outline.withValues(alpha: 0.2)),
      ),
      color: theme.colorScheme.surfaceContainerLowest,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              book.title,
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w700,
                height: 1.2,
              ),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.person_outline, size: 18, color: theme.colorScheme.onSurface.withValues(alpha: 0.7)),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    book.displayAuthor,
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: theme.colorScheme.onSurface.withValues(alpha: 0.9),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                if (book.firstPublishYear != null)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primary.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: theme.colorScheme.primary.withValues(alpha: 0.2)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.calendar_today_outlined, size: 12, color: theme.colorScheme.primary),
                        const SizedBox(width: 4),
                        Text(
                          book.publishYear,
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: theme.colorScheme.primary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                if (book.hasRating)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.amber.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.amber.withValues(alpha: 0.3)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.star, size: 12, color: Colors.amber),
                        const SizedBox(width: 4),
                        Text(
                          book.formattedRating,
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: theme.colorScheme.onSurface,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context, book) {
    final theme = Theme.of(context);
    return Row(
      children: [
        Expanded(
          child: FilledButton.icon(
            onPressed: book.hasPdf
                ? () {
                    HapticFeedback.selectionClick();
                    _openPdf(book);
                  }
                : null,
            icon: const Icon(Icons.picture_as_pdf),
            label: Text(book.hasPdf ? 'Read PDF' : 'PDF Not Available'),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () {
              HapticFeedback.selectionClick();
              _shareBook(book);
            },
            icon: const Icon(Icons.share),
            label: const Text('Share'),
            style: OutlinedButton.styleFrom(
              foregroundColor: theme.colorScheme.primary,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDescriptionSection(BuildContext context, book) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Description', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: theme.colorScheme.outline.withValues(alpha: 0.15)),
          ),
          color: theme.colorScheme.surfaceContainerLowest,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              book.description!,
              style: theme.textTheme.bodyMedium?.copyWith(height: 1.5),
            ),
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildSubjectsSection(BuildContext context, book) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Subjects', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: book.subjects.map<Widget>((subject) {
            return Chip(
              label: Text(subject),
              backgroundColor: theme.primaryColor.withValues(alpha: 0.1),
              side: BorderSide.none,
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildLoadingState() {
    return const BookDetailSkeleton();
  }

  Widget _buildErrorState(BookDetailController controller) {
    return AppStateMessage(
      icon: Icons.error_outline,
      iconColor: Colors.red,
      title: 'Failed to load book details',
      message: controller.error.value,
      primaryLabel: 'Retry',
      onPrimary: controller.retry,
    );
  }

  Widget _buildNotFoundState() {
    return const AppStateMessage(
      icon: Icons.search_off,
      title: 'Book not found',
      message: 'The requested book could not be found.',
    );
  }

  void _openPdf(dynamic book) {
    if (book.hasPdf) {
      AppNavigation.toPdfViewer(pdfUrl: book.pdfUrl!, title: book.title);
    }
  }

  void _shareBook(dynamic book) async {
    final deepLinkService = Get.find<DeepLinkService>();
    final bookLink = deepLinkService.createBookLink(book.workId);

    await SharePlus.instance.share(
      ShareParams(
        text:
            'Check out "${book.title}" by ${book.displayAuthor}\n\n'
            'Read it here: $bookLink',
      ),
    );
  }
}
