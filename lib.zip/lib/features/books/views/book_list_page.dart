import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:link/shared/widgets/app_state_message.dart';
import '../../../shared/widgets/skeleton_loader.dart';

import '../../../core/routes/app_routes.dart';
import '../controllers/book_controller.dart';
import '../widgets/optimized_book_card.dart';

/// Enhanced book list page - stateless implementation with GetX
class BookListPage extends StatelessWidget {
  final bool isSearchMode;

  const BookListPage({super.key, this.isSearchMode = false});
  
  BookController get controller => Get.find<BookController>();

  void _onSearchChanged(String query) {
    if (query.trim().isNotEmpty) {
      controller.searchBooks(query.trim());
    }
  }

  void _onBookTapped(String bookId) {
    HapticFeedback.selectionClick();
    AppNavigation.toBookDetail(bookId);
  }

  Future<void> _onRefresh() async {
    final query = Get.arguments?['query'] as String?;
    controller.books.clear();
    
    if (isSearchMode && query != null && query.isNotEmpty) {
      await controller.searchBooks(query);
    } else {
      await controller.fetchBooksDefault();
    }
  }

  @override
  Widget build(BuildContext context) {
    // Initialize controller and setup
    final bookController = Get.put(BookController());
    final searchController = TextEditingController();
    final scrollController = ScrollController();
    
    // Setup initial data loading
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!isSearchMode) {
        bookController.fetchBooksDefault();
      } else {
        final args = Get.arguments as Map<String, dynamic>?;
        final query = args?['query'] as String?;
        if (query != null && query.isNotEmpty) {
          searchController.text = query;
          bookController.searchBooks(query);
        }
      }
    });
    
    // Setup infinite scroll listener
    scrollController.addListener(() {
      if (scrollController.position.pixels >=
          scrollController.position.maxScrollExtent - 200) {
        bookController.loadMoreBooks();
      }
    });

    return Scaffold(
      body: RefreshIndicator.adaptive(
        onRefresh: _onRefresh,
        edgeOffset: 0,
        child: CustomScrollView(
          controller: scrollController,
          physics: const BouncingScrollPhysics(),
          slivers: [
            _buildSliverAppBar(context),
            if (isSearchMode)
              SliverToBoxAdapter(
                child: _buildSearchBar(searchController),
              )
            else
              SliverToBoxAdapter(
                child: _buildQuickSearch(searchController),
              ),
            Obx(() => _buildSliverBookList()),
          ],
        ),
      ),
    );
  }

  Widget _buildSliverAppBar(BuildContext context) {
    return SliverAppBar(
      expandedHeight: 120,
      collapsedHeight: 64,
      floating: false,
      pinned: true,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      flexibleSpace: FlexibleSpaceBar(
        title: Text(
          isSearchMode ? 'Search Books' : 'Discover Books',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
            color: Theme.of(context).colorScheme.onSurface,
          ),
        ),
        centerTitle: false,
        titlePadding: const EdgeInsets.only(left: 16, bottom: 8),
        background: isSearchMode
            ? null
            : Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Theme.of(context).primaryColor.withValues(alpha: 0.1),
                      Theme.of(context).scaffoldBackgroundColor,
                    ],
                  ),
                ),
              ),
      ),
      actions: [
        if (!isSearchMode)
          IconButton(
            onPressed: () => AppNavigation.toSearch(),
            icon: const Icon(Icons.search),
            tooltip: 'Search Books',
          ),
      ],
    );
  }

  Widget _buildSearchBar(TextEditingController searchController) {
    return Container(
      padding: const EdgeInsets.all(16),
      child: TextField(
        controller: searchController,
        decoration: InputDecoration(
          hintText: 'Search for books...',
          prefixIcon: const Icon(Icons.search),
          suffixIcon: searchController.text.isNotEmpty
              ? IconButton(
                  onPressed: () {
                    searchController.clear();
                    controller.books.clear();
                  },
                  icon: const Icon(Icons.clear),
                )
              : null,
          border: const OutlineInputBorder(),
        ),
        onSubmitted: _onSearchChanged,
        textInputAction: TextInputAction.search,
      ),
    );
  }

  Widget _buildQuickSearch(TextEditingController searchController) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: searchController,
              decoration: InputDecoration(
                hintText: 'Quick search...',
                prefixIcon: const Icon(Icons.search),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25),
                ),
              ),
              onSubmitted: _onSearchChanged,
            ),
          ),
          const SizedBox(width: 8),
          IconButton(
            onPressed: () => AppNavigation.toSearch(),
            icon: const Icon(Icons.tune),
            tooltip: 'Advanced Search',
          ),
        ],
      ),
    );
  }

  Widget _buildSliverBookList() {
    if (controller.isLoading.value && controller.books.isEmpty) {
      return SliverFillRemaining(child: _buildLoadingState());
    }

    if (controller.error.value.isNotEmpty && controller.books.isEmpty) {
      return SliverFillRemaining(child: _buildErrorState());
    }

    if (controller.books.isEmpty) {
      return SliverFillRemaining(child: _buildEmptyState());
    }

    return SliverPadding(
      padding: const EdgeInsets.all(16),
      sliver: SliverList(
        delegate: SliverChildBuilderDelegate(
          (context, index) {
            if (index == controller.books.length) {
              return _buildBottomLoader();
            }

            final book = controller.books[index];
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: OptimizedBookCard(
                book: book,
                onTap: () => _onBookTapped(book.workId),
                index: index,
              ),
            );
          },
          childCount:
              controller.books.length + (controller.hasMore.value ? 1 : 0),
        ),
      ),
    );
  }



  Widget _buildLoadingState() {
    return const BookListSkeleton(itemCount: 8);
  }

  Widget _buildErrorState() {
    return AppStateMessage(
      icon: Icons.error_outline,
      iconColor: Colors.red,
      title: 'Something went wrong',
      message: controller.error.value,
      primaryLabel: 'Retry',
      onPrimary: controller.retryFetching,
    );
  }

  Widget _buildEmptyState() {
    final searchMode =
        isSearchMode || controller.currentQuery.value.isNotEmpty;

    return AppStateMessage(
      icon: searchMode ? Icons.search_off : Icons.library_books,
      title: searchMode ? 'No books found' : 'Welcome to Open Library',
      message: searchMode
          ? 'Try a different search term'
          : 'Search for books to get started',
      primaryLabel: searchMode ? null : 'Start Searching',
      onPrimary: searchMode ? null : () => AppNavigation.toSearch(),
    );
  }

  Widget _buildBottomLoader() {
    return Container(
      padding: const EdgeInsets.all(16),
      alignment: Alignment.center,
      child: controller.isLoadingMore.value
          ? Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Get.theme.colorScheme.primary,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  'Loading more books...',
                  style: Get.textTheme.bodyMedium?.copyWith(
                    color: Get.theme.colorScheme.onSurface.withValues(alpha: 0.7),
                  ),
                ),
              ],
            )
          : const SizedBox.shrink(),
    );
  }
}
