import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

import '../controllers/home_controller.dart';
import '../../books/views/book_list_page.dart';
import '../../books/views/favorites_page.dart';
import '../../profile/views/profile_page.dart';
import '../../books/views/categories_page.dart';

/// Main home page with bottom navigation
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(HomeController());

    return Scaffold(
      body: Obx(() => AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        transitionBuilder: (child, animation) {
          return FadeTransition(
            opacity: animation,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0.1, 0),
                end: Offset.zero,
              ).animate(CurvedAnimation(
                parent: animation,
                curve: Curves.easeOutCubic,
              )),
              child: child,
            ),
          );
        },
        child: _buildCurrentPage(controller.currentIndex.value),
      )),
      bottomNavigationBar: Obx(() => _buildBottomNavigationBar(context, controller)),
    );
  }

  Widget _buildCurrentPage(int index) {
    switch (index) {
      case 0:
        return const BookListPage(key: ValueKey('home'));
      case 1:
        return const CategoriesPage(key: ValueKey('categories'));
      case 2:
        return const FavoritesPage(key: ValueKey('favorites'));
      case 3:
        return const ProfilePage(key: ValueKey('profile'));
      default:
        return const BookListPage(key: ValueKey('home'));
    }
  }

  Widget _buildBottomNavigationBar(BuildContext context, HomeController controller) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).bottomNavigationBarTheme.backgroundColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildNavItem(
                context: context,
                controller: controller,
                index: 0,
                icon: Icons.home_outlined,
                activeIcon: Icons.home,
                label: 'Home',
              ),
              _buildNavItem(
                context: context,
                controller: controller,
                index: 1,
                icon: Icons.category_outlined,
                activeIcon: Icons.category,
                label: 'Categories',
              ),
              _buildNavItem(
                context: context,
                controller: controller,
                index: 2,
                icon: Icons.favorite_outline,
                activeIcon: Icons.favorite,
                label: 'Favorites',
              ),
              _buildNavItem(
                context: context,
                controller: controller,
                index: 3,
                icon: Icons.person_outline,
                activeIcon: Icons.person,
                label: 'Profile',
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem({
    required BuildContext context,
    required HomeController controller,
    required int index,
    required IconData icon,
    required IconData activeIcon,
    required String label,
  }) {
    final isActive = controller.currentIndex.value == index;
    final theme = Theme.of(context);

    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        controller.changeTab(index);
      },
        child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        curve: Curves.easeOutCubic,
        decoration: BoxDecoration(
          color: isActive 
            ? theme.primaryColor.withValues(alpha: 0.1)
            : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isActive ? activeIcon : icon,
              color: isActive 
                ? theme.primaryColor
                : theme.colorScheme.onSurface.withValues(alpha: 0.6),
              size: 24,
            ),
            if (isActive) ...[
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  color: theme.primaryColor,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
