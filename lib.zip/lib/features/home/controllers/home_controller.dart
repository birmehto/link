import 'package:get/get.dart';

/// Controller for managing bottom navigation state
class HomeController extends GetxController {
  final currentIndex = 0.obs;

  void changeTab(int index) {
    currentIndex.value = index;
  }

  void goToHome() => changeTab(0);
  void goToCategories() => changeTab(1);
  void goToFavorites() => changeTab(2);
  void goToProfile() => changeTab(3);
}
