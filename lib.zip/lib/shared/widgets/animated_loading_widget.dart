import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:shimmer/shimmer.dart';
import 'package:get/get.dart';

/// Enhanced animated loading widget with multiple loading states
class AnimatedLoadingWidget extends StatelessWidget {
  final String message;
  final LoadingType type;
  final double? progress; // For determinate progress (0.0 - 1.0)
  final Color? color;
  final double size;

  const AnimatedLoadingWidget({
    super.key,
    this.message = 'Loading...',
    this.type = LoadingType.circular,
    this.progress,
    this.color,
    this.size = 80,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final effectiveColor = color ?? theme.colorScheme.primary;

    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildLoadingIndicator(theme, effectiveColor),
          if (message.isNotEmpty) ...[
            SizedBox(height: size * 0.3),
            _buildLoadingText(theme),
          ],
          if (progress != null) ...[
            const SizedBox(height: 12),
            _buildProgressText(theme),
          ],
        ],
      ).animate().fadeIn(duration: 300.ms).scale(
            begin: const Offset(0.8, 0.8),
            duration: 400.ms,
            curve: Curves.easeOutBack,
          ),
    );
  }

  Widget _buildLoadingIndicator(ThemeData theme, Color effectiveColor) {
    switch (type) {
      case LoadingType.circular:
        return _buildCircularIndicator(effectiveColor);
      case LoadingType.linear:
        return _buildLinearIndicator(theme, effectiveColor);
      case LoadingType.pulse:
        return _buildPulseIndicator(effectiveColor);
      case LoadingType.spin:
        return _buildSpinIndicator(effectiveColor);
      case LoadingType.dots:
        return _buildDotsIndicator(effectiveColor);
      case LoadingType.wave:
        return _buildWaveIndicator(effectiveColor);
      case LoadingType.shimmer:
        return _buildShimmerIndicator(theme);
    }
  }

  Widget _buildCircularIndicator(Color color) {
    return SizedBox(
      width: size,
      height: size,
      child: CircularProgressIndicator(
        strokeWidth: size * 0.06,
        value: progress,
        valueColor: AlwaysStoppedAnimation<Color>(color),
        backgroundColor: color.withValues(alpha: 0.2),
      ),
    );
  }

  Widget _buildLinearIndicator(ThemeData theme, Color color) {
    return Container(
      width: size * 2,
      height: 6,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(3),
        color: color.withValues(alpha: 0.2),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(3),
        child: LinearProgressIndicator(
          value: progress,
          valueColor: AlwaysStoppedAnimation<Color>(color),
          backgroundColor: Colors.transparent,
        ),
      ),
    );
  }

  Widget _buildPulseIndicator(Color color) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color.withValues(alpha: 0.3),
      ),
    )
        .animate(onPlay: (controller) => controller.repeat())
        .scale(
          begin: const Offset(0.5, 0.5),
          end: const Offset(1.2, 1.2),
          duration: 1000.ms,
          curve: Curves.easeInOut,
        )
        .then()
        .scale(
          begin: const Offset(1.2, 1.2),
          end: const Offset(0.5, 0.5),
          duration: 1000.ms,
          curve: Curves.easeInOut,
        );
  }

  Widget _buildSpinIndicator(Color color) {
    return Icon(
      Icons.refresh,
      size: size,
      color: color,
    )
        .animate(onPlay: (controller) => controller.repeat())
        .rotate(duration: 1000.ms, curve: Curves.linear);
  }

  Widget _buildDotsIndicator(Color color) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(3, (index) {
        return Container(
          margin: EdgeInsets.symmetric(horizontal: size * 0.05),
          width: size * 0.2,
          height: size * 0.2,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color,
          ),
        )
            .animate(
              onPlay: (controller) => controller.repeat(),
              delay: Duration(milliseconds: index * 200),
            )
            .moveY(
              begin: 0,
              end: -size * 0.3,
              duration: 600.ms,
              curve: Curves.easeInOut,
            )
            .then()
            .moveY(
              begin: -size * 0.3,
              end: 0,
              duration: 600.ms,
              curve: Curves.easeInOut,
            );
      }),
    );
  }

  Widget _buildWaveIndicator(Color color) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (index) {
        return Container(
          margin: EdgeInsets.symmetric(horizontal: size * 0.02),
          width: size * 0.08,
          height: size * 0.6,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(size * 0.04),
            color: color,
          ),
        )
            .animate(
              onPlay: (controller) => controller.repeat(),
              delay: Duration(milliseconds: index * 100),
            )
            .scaleY(
              begin: 0.3,
              end: 1.0,
              duration: 500.ms,
              curve: Curves.easeInOut,
            )
            .then()
            .scaleY(
              begin: 1.0,
              end: 0.3,
              duration: 500.ms,
              curve: Curves.easeInOut,
            );
      }),
    );
  }

  Widget _buildShimmerIndicator(ThemeData theme) {
    return Shimmer.fromColors(
      baseColor: theme.colorScheme.surfaceContainer,
      highlightColor: theme.colorScheme.surface,
      child: Column(
        children: [
          Container(
            width: size,
            height: size * 0.6,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 12),
          Container(
            width: size * 1.2,
            height: 16,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            width: size * 0.8,
            height: 12,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingText(ThemeData theme) {
    return Text(
      message,
      style: theme.textTheme.titleMedium?.copyWith(
        color: theme.colorScheme.onSurface.withValues(alpha: 0.8),
        fontWeight: FontWeight.w500,
      ),
      textAlign: TextAlign.center,
    )
        .animate(onPlay: (controller) => controller.repeat())
        .fade(
          begin: 0.5,
          end: 1.0,
          duration: 800.ms,
          curve: Curves.easeInOut,
        )
        .then()
        .fade(
          begin: 1.0,
          end: 0.5,
          duration: 800.ms,
          curve: Curves.easeInOut,
        );
  }

  Widget _buildProgressText(ThemeData theme) {
    final percentage = (progress! * 100).clamp(0, 100).toInt();
    return Text(
      '$percentage%',
      style: theme.textTheme.bodyMedium?.copyWith(
        color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
        fontWeight: FontWeight.w500,
      ),
    );
  }
}

/// Different types of loading animations
enum LoadingType {
  circular,
  linear,
  pulse,
  spin,
  dots,
  wave,
  shimmer,
}

/// Extension for easy loading overlay
extension LoadingOverlay on Widget {
  Widget withLoading({
    required bool isLoading,
    String message = 'Loading...',
    LoadingType type = LoadingType.circular,
    double? progress,
    Color? color,
  }) {
    return Stack(
      children: [
        this,
        if (isLoading)
          Container(
        color: Get.theme.scaffoldBackgroundColor.withValues(alpha: 0.8),
            child: AnimatedLoadingWidget(
              message: message,
              type: type,
              progress: progress,
              color: color,
            ),
          ),
      ],
    );
  }
}

/// Loading state for lists
class LoadingListItem extends StatelessWidget {
  const LoadingListItem({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Shimmer.fromColors(
      baseColor: theme.colorScheme.surfaceContainer,
      highlightColor: theme.colorScheme.surface,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 80,
                height: 120,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: double.infinity,
                      height: 20,
                      color: Colors.white,
                    ),
                    const SizedBox(height: 8),
                    Container(
                      width: 150,
                      height: 16,
                      color: Colors.white,
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Container(
                          width: 60,
                          height: 24,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          width: 40,
                          height: 24,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
