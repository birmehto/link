import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import 'app/app.dart';
import 'core/core.dart';
import 'features/books/services/book_service.dart';

/// Application entry point
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize core services
  await _initializeServices();

  // Set system UI configuration
  await _configureSystemUI();

  // Set up global error handling
  _setupErrorHandling();

  runApp(const BookApp());
}

/// Initialize all required services
Future<void> _initializeServices() async {
  // Initialize logger first
  await AppLogger.initialize();
  final logger = AppLogger('Main');
  logger.info('Initializing application services...');

  try {
    // Initialize storage
    await GetStorage.init();
    logger.info('Storage initialized');

    // Register core services
    final apiClient = ApiClient();
    await apiClient.init();
    Get.put(apiClient, permanent: true);
    logger.info('API client initialized');

    Get.put(DeepLinkService(), permanent: true);
    logger.info('Deep link service initialized');

    // Initialize network service
    Get.put(NetworkService(), permanent: true);
    logger.info('Network service initialized');

    // Initialize book service
    Get.put(BookService(), permanent: true);
    logger.info('Book service initialized');

    logger.info('All services initialized successfully');
  } catch (e, stackTrace) {
    final logger = AppLogger('ServiceInit');
    logger.error(
      'Failed to initialize services',
      error: e,
      stackTrace: stackTrace,
    );
    rethrow;
  }
}

/// Configure system UI (status bar, navigation bar, etc.)
Future<void> _configureSystemUI() async {
  // Set preferred orientations
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Configure system UI overlay style
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );
}

/// Set up global error handling
void _setupErrorHandling() {
  final logger = AppLogger('ErrorHandler');

  // Handle Flutter errors
  FlutterError.onError = (FlutterErrorDetails details) {
    logger.error(
      'Flutter Error: ${details.exceptionAsString()}',
      error: details.exception,
      stackTrace: details.stack,
    );

    // Report to crash analytics in production
    // FirebaseCrashlytics.instance.recordFlutterError(details);
  };

  // Handle platform errors (async errors not caught by Flutter)
  PlatformDispatcher.instance.onError = (error, stack) {
    logger.error('Platform Error: $error', error: error, stackTrace: stack);

    // Report to crash analytics in production
    // FirebaseCrashlytics.instance.recordError(error, stack);

    return true;
  };
}
