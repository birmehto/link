import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../core/core.dart';

/// Main application widget
class BookApp extends StatelessWidget {
  const BookApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Open Library',
      debugShowCheckedModeBanner: false,
      
      // Theme configuration
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system,
      
      // Navigation configuration
      initialRoute: AppRoutes.home,
      getPages: AppPages.pages,
      defaultTransition: AppPages.defaultTransition,
      transitionDuration: AppPages.transitionDuration,
      
      // Logging configuration
      enableLog: true,
      logWriterCallback: _handleGetXLogs,
      
      // Global app configuration
      builder: (context, child) {
        return MediaQuery(
          // Lock text scaling to prevent UI breakage
          data: MediaQuery.of(context).copyWith(
            textScaler: const TextScaler.linear(1.0),
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
      
      // Unknown route handling
      unknownRoute: GetPage(
        name: '/not-found',
        page: () => const _NotFoundPage(),
      ),
      
      // Locale configuration
      locale: const Locale('en', 'US'),
      fallbackLocale: const Locale('en', 'US'),
      
      // Accessibility
      debugShowMaterialGrid: false,
      showPerformanceOverlay: false,
      
      // Error handling
      routingCallback: (routing) {
        final logger = AppLogger('Navigation');
        logger.debug('Navigation: ${routing?.current} -> ${routing?.previous}');
      },
    );
  }

  /// Handle GetX framework logs
  void _handleGetXLogs(String text, {bool isError = false}) {
    final logger = AppLogger('GetX');
    
    if (isError) {
      logger.error(text);
    } else if (text.startsWith('[GETX]')) {
      logger.debug(text);
    } else {
      logger.trace(text);
    }
  }
}

/// 404 page for unknown routes
class _NotFoundPage extends StatelessWidget {
  const _NotFoundPage();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Page Not Found'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => AppNavigation.toHome(),
        ),
      ),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 64,
              color: Colors.grey,
            ),
            SizedBox(height: 16),
            Text(
              '404 - Page Not Found',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'The page you are looking for does not exist.',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 32),
            ElevatedButton(
              onPressed: AppNavigation.toHome,
              child: Text('Go Home'),
            ),
          ],
        ),
      ),
    );
  }
}
